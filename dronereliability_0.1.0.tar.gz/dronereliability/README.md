# demotool
- **Description**: Repository for demoing how to make a usable tool in an R package
- **Author**: Tim Fraser, PhD

## How to Install Our Package

```r
# Install from devtools, using dependencies!
devtools::install_github("LeslieChiu007/dronereliability", dependencies = TRUE)

library(dronereliability)
dronereliability::get_stats()
```

## Workflow

See Workflow .....